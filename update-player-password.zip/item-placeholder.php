<li class="card <?= $i->item_type; ?> relative white-bg blend-luminosity" style="background-image: url(<?= $i->item_badge; ?>);" id="item-card-<?= $i->item_id; ?>">
</li>
