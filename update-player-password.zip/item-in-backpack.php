<li class="<?= $i->item_type; ?> cursor-pointer" style="background-image: url(<?= $i->item_badge; ?>);" id="item-card-<?= $i->item_id; ?>" onClick="loadBackpackItem(<?= $i->item_id; ?>);">
</li>
