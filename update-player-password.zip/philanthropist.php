<h3><strong><?php _e("Intrinsically motivated by",'bluerabbit'); ?></strong></h3>
<p>
	<?php _e("Philanthropists are motivated by Purpose and Meaning. This group are altruistic, wanting to give to other people and enrich the lives of others in some way with no expectation of reward","bluerabbit"); ?>
</p>
<p>
	<?php _e("Philanthropists want to feel that they are part of something bigger. They want to give to others but expect nothing in return. These are the ones who will answer endless questions on forums, just because they like to feel they are helping. They want a system that allows them to enrich others and feel a sense of altruism and purpose.","bluerabbit"); ?>
</p>
<h3><strong><?php _e("Self Seeker",'bluerabbit'); ?>, </strong><?php _e("philanthropist motivated by REWARDS",'bluerabbit'); ?></h3>
<p>
	<?php _e("This group of users will act in a similar way to Philanthropists. They will answer people’s questions, share knowledge and be helpful – but for a cost. If there is no reward, don’t expect them to get involved! They can be useful, however, if they are being asked to get involved for rewards, expect quantity over quality!","bluerabbit"); ?>
</p>
<h3><strong><?php _e("Griefer",'bluerabbit'); ?>, </strong><?php _e("philanthropist as a DISRUPTOR",'bluerabbit'); ?></h3>
<p>
	<?php _e("This is our Killer (yep, finally I have an answer for those who kept asking where it was!). I have chosen to use Bartle’s description from his 8 types because this is the pure arsehole type. They want to negatively affect other users, just because they can. It may be to prove a point about the fact they don’t like the system, it may just be for fun. They have no place in most gamified systems, so you need to find ways to either change their minds – or get rid of them.","bluerabbit"); ?>
</p>
