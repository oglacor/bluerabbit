<li class="<?= $i->item_type; ?> cursor-pointer" style="background-image: url(<?= $i->item_badge; ?>);" id="item-card-<?= $i->item_id; ?>" onClick="loadItemCard(<?= $i->item_id; ?>);">
</li>
