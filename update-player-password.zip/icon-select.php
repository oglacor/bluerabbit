


<div class="icon-select">
<button class="relative button form-ui stopwatch-icon-button font _24 sq-40  <?php if($selected_icon == 'stopwatch'){echo 'active';} ?>" onClick="setIconTo('stopwatch');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-stopwatch"></span>
	</button>
<button class="relative button form-ui sabotage-icon-button font _24 sq-40  <?php if($selected_icon == 'sabotage'){echo 'active';} ?>" onClick="setIconTo('sabotage');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-sabotage"></span>
	</button>
<button class="relative button form-ui tools-icon-button font _24 sq-40  <?php if($selected_icon == 'tools'){echo 'active';} ?>" onClick="setIconTo('tools');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-tools"></span>
	</button>
<button class="relative button form-ui tw-icon-button font _24 sq-40  <?php if($selected_icon == 'tw'){echo 'active';} ?>" onClick="setIconTo('tw');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-tw"></span>
	</button>
<button class="relative button form-ui run-icon-button font _24 sq-40  <?php if($selected_icon == 'run'){echo 'active';} ?>" onClick="setIconTo('run');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-run"></span>
	</button>
<button class="relative button form-ui time-icon-button font _24 sq-40  <?php if($selected_icon == 'time'){echo 'active';} ?>" onClick="setIconTo('time');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-time"></span>
	</button>
<button class="relative button form-ui socialiser-icon-button font _24 sq-40  <?php if($selected_icon == 'socialiser'){echo 'active';} ?>" onClick="setIconTo('socialiser');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-socialiser"></span>
	</button>
<button class="relative button form-ui megaphone-icon-button font _24 sq-40  <?php if($selected_icon == 'megaphone'){echo 'active';} ?>" onClick="setIconTo('megaphone');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-megaphone"></span>
	</button>
<button class="relative button form-ui max-icon-button font _24 sq-40  <?php if($selected_icon == 'max'){echo 'active';} ?>" onClick="setIconTo('max');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-max"></span>
	</button>
<button class="relative button form-ui narrative-icon-button font _24 sq-40  <?php if($selected_icon == 'narrative'){echo 'active';} ?>" onClick="setIconTo('narrative');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-narrative"></span>
	</button>
<button class="relative button form-ui goal-icon-button font _24 sq-40  <?php if($selected_icon == 'goal'){echo 'active';} ?>" onClick="setIconTo('goal');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-goal"></span>
	</button>
<button class="relative button form-ui quest-icon-button font _24 sq-40  <?php if($selected_icon == 'quest'){echo 'active';} ?>" onClick="setIconTo('quest');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-quest"></span>
	</button>
<button class="relative button form-ui comment-icon-button font _24 sq-40  <?php if($selected_icon == 'comment'){echo 'active';} ?>" onClick="setIconTo('comment');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-comment"></span>
	</button>
<button class="relative button form-ui story-icon-button font _24 sq-40  <?php if($selected_icon == 'story'){echo 'active';} ?>" onClick="setIconTo('story');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-story"></span>
	</button>
<button class="relative button form-ui logo-icon-button font _24 sq-40  <?php if($selected_icon == 'logo'){echo 'active';} ?>" onClick="setIconTo('logo');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-logo"></span>
	</button>
<button class="relative button form-ui mission-icon-button font _24 sq-40  <?php if($selected_icon == 'mission'){echo 'active';} ?>" onClick="setIconTo('mission');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-mission"></span>
	</button>
<button class="relative button form-ui magic-icon-button font _24 sq-40  <?php if($selected_icon == 'magic'){echo 'active';} ?>" onClick="setIconTo('magic');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-magic"></span>
	</button>
<button class="relative button form-ui freespirit-icon-button font _24 sq-40  <?php if($selected_icon == 'freespirit'){echo 'active';} ?>" onClick="setIconTo('freespirit');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-freespirit"></span>
	</button>
<button class="relative button form-ui document-icon-button font _24 sq-40  <?php if($selected_icon == 'document'){echo 'active';} ?>" onClick="setIconTo('document');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-document"></span>
	</button>
<button class="relative button form-ui enemy-icon-button font _24 sq-40  <?php if($selected_icon == 'enemy'){echo 'active';} ?>" onClick="setIconTo('enemy');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-enemy"></span>
	</button>
<button class="relative button form-ui favorite-icon-button font _24 sq-40  <?php if($selected_icon == 'favorite'){echo 'active';} ?>" onClick="setIconTo('favorite');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-favorite"></span>
	</button>
<button class="relative button form-ui world-icon-button font _24 sq-40  <?php if($selected_icon == 'world'){echo 'active';} ?>" onClick="setIconTo('world');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-world"></span>
	</button>
<button class="relative button form-ui ticket-icon-button font _24 sq-40  <?php if($selected_icon == 'ticket'){echo 'active';} ?>" onClick="setIconTo('ticket');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-ticket"></span>
	</button>
<button class="relative button form-ui achiever-icon-button font _24 sq-40  <?php if($selected_icon == 'achiever'){echo 'active';} ?>" onClick="setIconTo('achiever');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-achiever"></span>
	</button>
<button class="relative button form-ui boundaries-icon-button font _24 sq-40  <?php if($selected_icon == 'boundaries'){echo 'active';} ?>" onClick="setIconTo('boundaries');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-boundaries"></span>
	</button>
<button class="relative button form-ui activity-icon-button font _24 sq-40  <?php if($selected_icon == 'activity'){echo 'active';} ?>" onClick="setIconTo('activity');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-activity"></span>
	</button>
<button class="relative button form-ui carrot-icon-button font _24 sq-40  <?php if($selected_icon == 'carrot'){echo 'active';} ?>" onClick="setIconTo('carrot');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-carrot"></span>
	</button>
<button class="relative button form-ui challenge-icon-button font _24 sq-40  <?php if($selected_icon == 'challenge'){echo 'active';} ?>" onClick="setIconTo('challenge');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-challenge"></span>
	</button>
<button class="relative button form-ui escape-room-icon-button font _24 sq-40  <?php if($selected_icon == 'escape-room'){echo 'active';} ?>" onClick="setIconTo('escape-room');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-escape-room"></span>
	</button>
<button class="relative button form-ui class-icon-button font _24 sq-40  <?php if($selected_icon == 'class'){echo 'active';} ?>" onClick="setIconTo('class');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-class"></span>
	</button>
<button class="relative button form-ui environment-icon-button font _24 sq-40  <?php if($selected_icon == 'environment'){echo 'active';} ?>" onClick="setIconTo('environment');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-environment"></span>
	</button>
<button class="relative button form-ui tag-icon-button font _24 sq-40  <?php if($selected_icon == 'tag'){echo 'active';} ?>" onClick="setIconTo('tag');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-tag"></span>
	</button>
<button class="relative button form-ui objectives-icon-button font _24 sq-40  <?php if($selected_icon == 'objectives'){echo 'active';} ?>" onClick="setIconTo('objectives');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-objectives"></span>
	</button>
<button class="relative button form-ui winstate-icon-button font _24 sq-40  <?php if($selected_icon == 'winstate'){echo 'active';} ?>" onClick="setIconTo('winstate');">
		<span class="background blue-bg-700 on"></span>
		<span class="background grey-bg-500 off"></span>
		<span class="foreground icon icon-winstate"></span>
	</button>
</div>
